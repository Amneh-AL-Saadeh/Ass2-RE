package I3.Classes;

/**
 * Represents a food item available in the hotel menu.
 * @author Faysal Ahmed
 */
public class Food {
    
    private int food_id;
    private String name;
    private int price;

    
    /**
     * @return the food item ID
     */
    public int getFood_id() {
        return food_id;
    }

    
    /**
     * @param food_id the food item ID to set
     */
    public void setFood_id(int food_id) {
        this.food_id = food_id;
    }

    
    /**
     * @return the name of the food item
     */
    public String getName() {
        return name;
    }

    
    /**
     * @param name the food item name to set
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * @return the price of the food item
     */
    public int getPrice() {
        return price;
    }

    /**
     * @param price the food item price to set
     */
    public void setPrice(int price) {
        this.price = price;
    }
    
    
    
}
