package I3.Classes;

import java.util.ArrayList;

/**
 * Represents a payment for a hotel booking including room charges and extra orders.
 * Handles calculation of total bill with optional discounts.
 * @author Faysal Ahmed
 */

public class Payment {
    
    //required Object
    private Booking booking;
    ArrayList<ExtraOrders> orders;
    int totalRentPrice;
    private String payment_date;
    private String payment_method;
    private boolean hasDiscount;
    private float discount;
    int totalBill;
    
    
    /**
     * Constructs a new Payment object for a specific booking.
     * @param b the booking for which payment is being made
     */
    public Payment(Booking b)
    {
        booking = b;
        totalRentPrice = b.getRoomsFare() * 1;
        
    }

    
    /**
     * @return the associated booking
     */
    public Booking getBooking() {
        return booking;
    }

    
    /**
     * @param booking the booking to set
     */
    public void setBooking(Booking booking) {
        this.booking = booking;
    }

    
     /**
     * @return the payment date
     */
    public String getPayment_date() {
        return payment_date;
    }

    
    /**
     * @param payment_date the payment date to set
     */
    public void setPayment_date(String payment_date) {
        this.payment_date = payment_date;
    }

    
    /**
     * @return the payment method
     */
    public String getPayment_method() {
        return payment_method;
    }

    
    /**
     * @param payment_method the payment method to set
     */
    public void setPayment_method(String payment_method) {
        this.payment_method = payment_method;
    }

    
    /**
     * @return true if discount is applied, false otherwise
     */
    public boolean isHasDiscount() {
        return hasDiscount;
    }

    
    /**
     * @param hasDiscount set whether discount is applied
     */
    public void setHasDiscount(boolean hasDiscount) {
        this.hasDiscount = hasDiscount;
    }

    
    /**
     * @return the discount percentage
     */
    public float getDiscount() {
        return discount;
    }
    

    /**
     * @param discount the discount percentage to set
     */
    public void setDiscount(float discount) {
        this.discount = discount;
    }
    
    
    /**
     * Calculates the total bill including room rent and extra orders.
     * Applies discount if applicable.
     * @return the total bill amount
     */
    public int calculateTotalBill()
    {
        int orderTotal = 0;
        
        for(ExtraOrders order: orders)
        {
            orderTotal += order.getQuantity() * order.getItem().getPrice();
        }
        totalBill = orderTotal+ totalRentPrice;
        
        return totalBill;
    }
    
    
    
    
    
}
