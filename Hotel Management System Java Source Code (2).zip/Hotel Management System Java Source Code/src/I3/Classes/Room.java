package I3.Classes;

/**
 * Represents a hotel room with its amenities and characteristics.
 * Manages room details including room number, bed count, available facilities, and pricing class.
 * @author Faysal Ahmed
 */
public class Room {
    private int room_id;
    private String room_no;
    private int bed_number;
    private boolean hasTV;
    private boolean hasWIFI;
    private boolean hasGizer;
    private boolean hasPhone;
    private RoomFare room_class;
    
    
     /**
     * Constructs a new Room with specified room number.
     * @param roomNo the room number to assign
     */
    public Room(String roomNo)
    {
        room_no = roomNo;
    }

    /**
     * @return the room ID
     */
    public int getRoom_id() {
        return room_id;
    }

    /**
     * @param room_id the room ID to set
     */
    public void setRoom_id(int room_id) {
        this.room_id = room_id;
    }

    
    /**
     * @return the room number
     */
    public String getRoom_no() {
        return room_no;
    }

    
    /**
     * @param room_no the room number to set
     */
    public void setRoom_no(String room_no) {
        this.room_no = room_no;
    }

    
    /**
     * @return the number of beds in the room
     */
    public int getBed_number() {
        return bed_number;
    }

    
    /**
     * @param bed_number the number of beds to set
     */
    public void setBed_number(int bed_number) {
        this.bed_number = bed_number;
    }

    
    /**
     * @return true if room has TV, false otherwise
     */
    public boolean isHasTV() {
        return hasTV;
    }
    
    
    /**
     * @param hasTV set whether room has TV
     */
    public void setHasTV(boolean hasTV) {
        this.hasTV = hasTV;
    }

    
    /**
     * @return true if room has WiFi, false otherwise
     */
    public boolean isHasWIFI() {
        return hasWIFI;
    }

    
    /**
     * @param hasWIFI set whether room has WiFi
     */
    public void setHasWIFI(boolean hasWIFI) {
        this.hasWIFI = hasWIFI;
    }

    
    /**
     * @return true if room has geyser, false otherwise
     */
    public boolean isHasGizer() {
        return hasGizer;
    }

    /**
     * @param hasGizer set whether room has geyser
     */
    public void setHasGizer(boolean hasGizer) {
        this.hasGizer = hasGizer;
    }

    
     /**
     * @return true if room has phone, false otherwise
     */
    public boolean isHasPhone() {
        return hasPhone;
    }

      /**
     * @param hasPhone set whether room has phone
     */
    public void setHasPhone(boolean hasPhone) {
        this.hasPhone = hasPhone;
    }


    /**
     * @return the room fare class
     */
    public RoomFare getRoom_class() {
        return room_class;
    }

    /**
     * @param room_class the room fare class to set
     */
    public void setRoom_class(RoomFare room_class) {
        this.room_class = room_class;
    }

  
    
    
    
    
}
