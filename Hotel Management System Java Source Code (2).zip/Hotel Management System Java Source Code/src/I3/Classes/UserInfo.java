/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package I3.Classes;

/**
 * Represents customer information in the hotel management system.
 * Stores essential customer details including contact information and type.
 * @author Faysal Ahmed
 */
public class UserInfo {
    
   
      
    //USER PROPERTIES
    private int customer_id;
    private String name;
    private String address;
    private String phone_no;
    private String type; // Customer type (e.g., Regular, VIP)

    /**
     * @return the customer ID
     */
    public int getCustomer_id() {
        return customer_id;
    }

    /**
     * @param customer_id the customer ID to set
     */
    public void setCustomer_id(int customer_id) {
        this.customer_id = customer_id;
    }

    /**
     * @return the customer name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the customer name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the customer address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the customer address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the customer phone number
     */
    public String getPhone_no() {
        return phone_no;
    }

    /**
     * @param phone_no the customer phone number to set
     */
    public void setPhone_no(String phone_no) {
        this.phone_no = phone_no;
    }

    /**
     * @return the customer type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the customer type to set
     */
    public void setType(String type) {
        this.type = type;
    }
    
    
    
    
    
}
