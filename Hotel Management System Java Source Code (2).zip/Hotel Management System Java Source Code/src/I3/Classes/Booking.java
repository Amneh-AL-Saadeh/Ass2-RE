package I3.Classes;

import java.util.ArrayList;
import java.util.Date;

/**
 * Represents a hotel booking in the system.
 * This class manages booking information including customer details,
 * room assignments, and booking dates.
 * @author Faysal Ahmed
 */
public class Booking {
    
  
    
    private UserInfo customer;
    ArrayList<Room> rooms;
    
    
    // Core attributes
    private int booking_id;
    private long checkInDateTime;
    private long checkOutDateTime;
    private String bookingType;
    private int person;
    
    
    /**
     * Constructs a new Booking with default values.
     * Initializes customer, empty room list, and sets booking as "Reserved".
     */
    
    public Booking()
    {
        
        customer = new UserInfo();
        rooms = new ArrayList<>();
        booking_id = -1;
        bookingType = "Reserved";
        
    }
    
    /**
     * @return the booking ID
     */

    public int getBooking_id() {
        return booking_id;
    }

    
     /**
     * @param booking_id the booking ID to set
     */
    public void setBooking_id(int booking_id) {
        this.booking_id = booking_id;
    }

   
    /**
     * @return the booking type (Reserved/Confirmed)
     */
    public String getBookingType() {
        return bookingType;
    }

    
    /**
     * @param bookingType the booking type to set
     */
    public void setBookingType(String bookingType) {
        this.bookingType = bookingType;
    }
    
    
    /**
     * Adds a new room to the booking
     * @param roomNo the room number to add
     */
    public void addRoom(String roomNo)
    {
        rooms.add(new Room(roomNo));
        
    }
    
    
    /**
     * Removes a room from the booking
     * @param roomNo the room number to remove
     */
    public void removeRoom(String roomNo)
    {
        for(Room a: rooms)
        {
            if(a.getRoom_no().equals(roomNo))
            {
                rooms.remove(a);
            }
        }
    }

    
    /**
     * @return number of persons in the booking
     */
    public int getPerson() {
        return person;
    }

    
    /**
     * @param person number of persons to set
     */
    public void setPerson(int person) {
        this.person = person;
    }

    
    /**
     * @return list of rooms in this booking
     */
    public ArrayList<Room> getRooms() {
        return rooms;
    }
    
    
    /**
     * Calculates total fare for all rooms in the booking
     * @return total room fare
     */
    public int getRoomsFare()
    {
        int total = 0;
        for(Room room:rooms)
        {
            total += room.getRoom_class().getPricePerDay();
        }
        return total;
    }

    
    /**
     * @return the customer information
     */
    public UserInfo getCustomer() {
        return customer;
    }

    
    /**
     * @param customer the customer to set
     */
    public void setCustomer(UserInfo customer) {
        this.customer = customer;
    }

    
    
    /**
     * @return the check-in date/time
     */
    public void setCheckOutDateTime(int checkOutDateTime) {
        this.checkOutDateTime = checkOutDateTime;
    }

    
    /**
     * @param checkInDateTime the check-in date/time to set
     */
    public long getCheckInDateTime() {
        return checkInDateTime;
    }

    
    /**
     * @return the check-out date/time
     */
    public void setCheckInDateTime(long checkInDateTime) {
        this.checkInDateTime = checkInDateTime;
    }

    
    /**
     * @return the check-out date/time
     */
    public long getCheckOutDateTime() {
        return checkOutDateTime;
    }

    
    /**
     * @param checkOutDateTime the check-out date/time to set
     */
    public void setCheckOutDateTime(long checkOutDateTime) {
        this.checkOutDateTime = checkOutDateTime;
    }

 
    
    
    
            
    
}
