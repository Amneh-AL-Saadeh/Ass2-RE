package I3.Classes;

/**
 * Represents pricing information for different types of hotel rooms.
 * Manages room types and their associated daily rates.
 * @author Faysal Ahmed
 */
public class RoomFare {
    
  
    private String room_type;
    private int pricePerDay;

  
  
    /**
     * @return the room type (e.g., Standard, Deluxe, Suite)
     */
    public String getRoom_type() {
        return room_type;
    }

     /**
     * @param room_type the room type to set
     */
    public void setRoom_type(String room_type) {
        this.room_type = room_type;
    }

    /**
     * @return the price per day for the room
     */
    public int getPricePerDay() {
        return pricePerDay;
    }

    /**
     * @param pricePerDay the daily price to set
     */
    public void setPricePerDay(int pricePerDay) {
        this.pricePerDay = pricePerDay;
    }
    
    
    
    
}
