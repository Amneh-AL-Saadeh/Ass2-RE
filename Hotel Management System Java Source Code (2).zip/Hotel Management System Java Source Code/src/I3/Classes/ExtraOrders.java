package I3.Classes;

/**
 * Represents extra orders/services requested by hotel customers.
 * @author Faysal Ahmed
 */
public class ExtraOrders {

    private int order_id;
    private int customer_id;
    private String dateTime;
    private int quantity;
    private Item item;

    
    /**
     * @return the order ID
     */
    public int getOrder_id() {
        return order_id;
    }

    
    /**
     * @param order_id the order ID to set
     */
    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    
    /**
     * @return the customer ID
     */
    public int getCustomer_id() {
        return customer_id;
    }

    
    /**
     * @param customer_id the customer ID to set
     */
    public void setCustomer_id(int customer_id) {
        this.customer_id = customer_id;
    }

    
    /**
     * @return the date and time of the order
     */
    public String getDateTime() {
        return dateTime;
    }

    
    /**
     * @param dateTime the date and time to set
     */
    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }
    
    /**
     * @return the quantity ordered
     */
    public int getQuantity() {
        return quantity;
    }

    
    /**
     * @param quantity the quantity to set
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    
    /**
     * @return the ordered item
     */
    public Item getItem() {
        return item;
    }

    
    /**
     * @param item the item to set
     */
    public void setItem(Item item) {
        this.item = item;
    }
    
    
    /**
     * Calculates the total cost of the order
     * @return total cost (item price * quantity)
     */
    public int calculateTotal()
    {
       return item.getPrice() * quantity;
    }

    
    
    
    
}
