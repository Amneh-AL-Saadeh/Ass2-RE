package I3.Classes;

/**
 * Represents a food order in the hotel booking system.
 * Links a food order to a specific booking and manages order details.
 * @author Faysal
 */
public class Order {
    
    int orderId;
    int bookingId;
    String foodItem;
    int price;
    int quantity;
    int total;

    
    /**
     * Constructs a new Order with specified details.
     * @param b booking ID associated with the order
     * @param f food item name
     * @param p price per item
     * @param q quantity ordered
     * @param t total cost of the order
     */
    public Order(int b,String f,int p,int q, int t)
    {
        bookingId = b;
        foodItem = f;
        price = p;
        quantity = q;
        total = t;
    }
    
    
    /**
     * @return the order ID
     */
    public int getOrderId() {
        return orderId;
    }

    
    /**
     * @param orderId the order ID to set
     */
    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    
    /**
     * @return the booking ID
     */
    public int getBookingId() {
        return bookingId;
    }

    
     /**
     * @param bookingId the booking ID to set
     */
    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    
    /**
     * @return the food item name
     */
    public String getFoodItem() {
        return foodItem;
    }

    
     /**
     * @param foodItem the food item name to set
     */
    public void setFoodItem(String foodItem) {
        this.foodItem = foodItem;
    }
    
    /**
     * @return the price per item
     */
    public int getPrice() {
        return price;
    }

    
    /**
     * @param price the price to set
     */
    public void setPrice(int price) {
        this.price = price;
    }

    
    /**
     * @return the quantity ordered
     */
    public int getQuantity() {
        return quantity;
    }

    
     /**
     * @param quantity the quantity to set
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    
    /**
     * @return the total cost of the order
     */
    public int getTotal() {
        return total;
    }

    
    /**
     * @param total the total cost to set
     */
    public void setTotal(int total) {
        this.total = total;
    }
    
    
    
}
