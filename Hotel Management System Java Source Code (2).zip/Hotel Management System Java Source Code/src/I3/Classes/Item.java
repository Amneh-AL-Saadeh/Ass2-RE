package I3.Classes;

/**
 * Represents an item available for purchase or use in the hotel.
 * This class manages basic item properties like ID, name, description, and price.
 * @author Faysal Ahmed
 */
public class Item {
    
    private int item_id;
    private String item_name;
    private String description;
    private int price;

    
    /**
     * @return the item ID
     */
    public int getItem_id() {
        return item_id;
    }

    
    /**
     * @param item_id the item ID to set
     */
    public void setItem_id(int item_id) {
        this.item_id = item_id;
    }

    
    /**
     * @return the item name
     */
    public String getItem_name() {
        return item_name;
    }

    
    /**
     * @param item_name the item name to set
     */
    public void setItem_name(String item_name) {
        this.item_name = item_name;
    }

    
    /**
     * @return the item description
     */
    public String getDescription() {
        return description;
    }

    
    /**
     * @param description the item description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    
    /**
     * @return the item price
     */
    public int getPrice() {
        return price;
    }

    
    /**
     * @param price the item price to set
     */
    public void setPrice(int price) {
        this.price = price;
    }

    
    
    
    
    
}
